

import java.util.Arrays;
import java.util.PriorityQueue;
import java.util.Random;

public class TestPQ
{
   public static void main(String[] args) {
      //Create an array called “smallData” of size 10 and initialize it with random integers between 0-999 (inclusive)
      Integer[] smallData = new Integer[10];
      //Create an array called “mediumData” of size 20 and initialize it with random integers between 0-999 (inclusive)
      Integer[] mediumData= new Integer[20];

      //Create a for loop that takes in the length size of the random integer produced into an arraylist
      for (int i = 0; i < smallData.length; i++) {
         //Creating the Random Number Variable
         Random number = new Random();
         //next int assigns the integer to a variable  x, and produces any number between 1 and 100000 because array size+1 is the index
         int x = 1 + number.nextInt(10000);
         smallData[i] = x;
      }
      for (int i = 0; i < mediumData.length; i++) {
         //Creating the Random Number Variable
         Random number = new Random();
         //next int assigns the integer to a variable  x, and produces any number between 1 and 100000 because array size+1 is the index
         int x = 1 + number.nextInt(10000);
         mediumData[i] = x;
      }

      // Create a PQ called “smallPQ” from the “smallData” array.
      PriorityQueue<Integer> smallPQ= new PriorityQueue<Integer>(Arrays.asList(smallData));// 🍉 might be wrong cause it was wrapped as list
//                Create a PQ called “mediumPQ” from the “mediumData” array.
      PriorityQueue<Integer> mediumPQ= new PriorityQueue<Integer>(Arrays.asList(mediumData)); //????
//                Combine “smallPQ” and “mediumPQ” as “result” PQ

      PriorityQueue<Integer> result = smallPQ.combined(mediumPQ);
//        Convert “result” PQ to an array called “list”
//        Print “list” array
//        Sort “list” array using HeapSort
//        Print “list” array


   }
}
